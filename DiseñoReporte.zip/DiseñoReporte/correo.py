import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
# Configura los detalles de tu servidor de correo SMTP
smtp_server = 'smtp.gmail.com'
smtp_port = 587
smtp_username = 'robmxz1234@gmail.com'
smtp_password = 'uyaaqdtiuvewalmc'

# Crea el objeto MIMEMultipart para el correo
msg = MIMEMultipart()
msg['From'] = 'robmxz1234@gmail.com'
msg['To'] = 'neiter.aylas@unmsm.edu.pe'
msg['Subject'] = 'Test casi listo :V'

# Crea el contenido HTML
html = """
<!DOCTYPE html>
<html>
  <head>
    <title>Reporte de rendimiento</title>
    <style>
      body {
    background-color: rgb(236, 206, 241);
    font-family: Verdana, Roboto;
    text-align: center;
    font-size: 2em;    
}

h1{
    text-transform: uppercase;
}

h2 {
    font-size: 150%;
}

h1,h2 {
    color: rgb(202, 130, 238);
}

table {
    float: left;
}
th {
    color: rgb(202, 130, 238);
}
.inicio {
    text-align: left;
    font-size:80%;
}

.inicio p{
    color:rgb(202, 130, 238);
}
.inicio span{
    color:black;
}
.Extras p,span{ 
    color:black;
    /*font-size: 50%;*/
}
#amb {
    font-weight: normal;
    /*font-size:medium;*/
    /* font-size: 50%;*/
}

.grafico {
    float: right;
    margin-left: 20px;
}

.banner {
    
    
}

.contenedor {
    display: flex;
    justify-content: center;
    float: center;
    font-size: 80%;
}
.Tabla1 {
    float: left;
    margin-right: 20px; 
    text-size-adjust: 100%;
}

#info {
    float: left;
}

    </style>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  </head>

  <body>

    <div class="banner">
      <img class ="image" src="https://d2z8zvwx6itreb.cloudfront.net/10-consejos-para-aprender-a-dibujar-kawaii-paso-a-paso-large-ZNMRru9DjJ.jpg">
    </div>

    <h1>Reporte de rendimiento</h1>

    <div class="inicio">
      <p>Estudiante: <span>[nombre y apellido]</span> </p> 
      <p>Código: <span>[codigo]</span></p>
      <p>Fecha de emisión: <span>[fecha]</span></p>
    </div>

    <h2 id="Resumen_notas">Resumen de notas</h2>
    <div class="contenedor">
      <div class="Tabla1">  
        <table class="Notas_por_area">
          <thead>
            <tr>
              <th>   Matematicas   </th>
              <th>   Humanidades   </th>
              <th>   Ciencias   </th>
              <th>   Promedio final   </th>
            </tr>        
          </thead>
            <tr>
              <td>   [nota mat]  </td>
              <td>   [nota hum]   </td>       
              <td>   [nota cien]   </td>  
              <td>   [nota fin]   </td>  
            </tr>
          </tbody>
        </table>
        <br>
        <p id="info">* En la sección derecha puede visualizar el seguimiento de notas</p>
      </div> 
      <div class="grafico">
        <img class ="image" src="https://upload.wikimedia.org/wikipedia/commons/d/d7/Commons_QR_code.png">
      </div>
    </div>
    

    <div class = "Extras">
      <h2>Estado de rendimiento:</h2> 
      <p id="amb">[alto/medio/bajo]</p>
      <h2>Posible problema que afectan su rendimiento</h2>
      <p>[posible problema]</p>
      <h2>Recomendaciones</h2>
      <p>[se programa o no cita con el psicopedagogo]</p>
    </div>
  </body>
</html>

"""

# Adjunta el contenido HTML al correo
msg.attach(MIMEText(html, 'html'))
csv_filename = 'student_data.csv'
attachment = open(csv_filename, 'rb')

part = MIMEBase('application', 'octet-stream')
part.set_payload((attachment).read())
encoders.encode_base64(part)
part.add_header('Content-Disposition', "attachment; filename= %s" % csv_filename)
msg.attach(part)
# Conéctate al servidor SMTP y envía el correo
try:
    server = smtplib.SMTP(smtp_server, smtp_port)
    server.starttls()
    server.login(smtp_username, smtp_password)
    server.sendmail(smtp_username, msg['To'], msg.as_string())
    server.quit()
    print("Correo enviado con éxito")
except Exception as e:
    print("Error al enviar el correo:", str(e))